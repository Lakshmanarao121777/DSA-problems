const findMaxNumber = (arr) => {
  let max = 0;
  for (let i = 0; i < arr.length - 1; i++) {
    for (let j = i + 1; j < arr.length; j++) {
      let product = arr[i] * arr[j];
      // usng Math function
      // max = Math.max(max, product);
      // using normal
      if (max < product) {
        max = product;
      }
    }
  }
  return max;
};

console.log(findMaxNumber([0, 2, -4, 9, 1, 3]));
