const selectionSort = (arr) => {
  const length = arr.length;
  for (let i = 0; i < arr.length; i++) {
    let min = i;

    for (let j = i; j < arr.length; j++) {
      if (arr[j] < arr[i]) {
        min = j;
      }
    }
    let temp = arr[min];
    arr[min] = arr[i];
    arr[i] = temp;
  }

  return arr;
};

console.log(selectionSort([1, 4, 3, 25, 2, 5, 9, 3, 5, 7, 0]));

// time complexity O(n^2)
