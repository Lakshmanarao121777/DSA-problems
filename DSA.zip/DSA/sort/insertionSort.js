const insertionSort = (arr) => {
  const length = arr.length;
  for (let i = 0; i < arr.length; i++) {
    let j = i - 1;
    while (j >= 0 && arr[j] > arr[i]) {
      arr[j + 1] = arr[j];
      j--;
    }
    arr[j + 1] = arr[i];
  }

  return arr;
};
console.log(insertionSort([1, 4, 3, 25, 2, 5, 9, 3, 5, 7, 0]));

// step 1. it will check first two digits
// step 2. if i > i + 1 satisfies then interchange

// step 2. then go for 2with 3..n positons if 2 > 3 satisfies then intercahnge, then  repeat previous steps
/** 
  1, 4, 3, 25, 2, 5, 9, 3, 5, 7, 0;
  0, 4, 3, 25, 2, 5, 9, 3, 5, 7, 1
*/