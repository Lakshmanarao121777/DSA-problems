const findSecondLargetNumber = (arr) => {
  let firstLarge = arr[0];
  let secondLarget = arr[0];
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] >= firstLarge) {
      firstLarge = arr[i];
    }
    if (arr[i] < firstLarge && arr[i] >= secondLarget) {
      secondLarget = arr[i];
    }
  }
  return secondLarget;
};
console.log(findSecondLargetNumber([1, 40, 33, 9, 4]));
