const findMissingNumber = (arr) => {
  const length = arr.length;
  const sum = (length * (length + 1)) / 2;
  const givenSum = arr.reduce((i, ps) => {
    return i + ps;
  }, 0);
  return sum - givenSum;
};


console.log(findMissingNumber([3, 0, 1]));
