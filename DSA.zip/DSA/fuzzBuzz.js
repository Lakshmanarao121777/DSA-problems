const fuzzBuzz = (num) => {
  if (num % 3 == 0 && num % 5 === 0) {
    return "Fuzz Buzz";
  } else if (num % 3 == 0) {
    return "Fuzz";
  } else if (num % 5 === 0) {
    return "Buzz";
  } else {
    return "";
  }
};
console.log(fuzzBuzz(15));
console.log(fuzzBuzz(10));
console.log(fuzzBuzz(9));
console.log(fuzzBuzz(8));
